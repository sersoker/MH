#! /bin/bash
g++ principal.cpp -std=c++11 libgtest.a libarff.a
./a.out