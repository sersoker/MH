#include "arff_parser.h"
#include <iostream>
using namespace std;


int main(){
	ArffParser parser("ejemplo.arff");
	ArffData *data = parser.parse();
	
	cout << data->num_attributes() << endl;
	cout << data->num_instances() << endl;
	
	ArffInstance *instancia = data->get_instance(1);
	ArffValue *valor;
	

	for (int i = 0; i < data->num_attributes(); i++) {
		valor = instancia->get(i);
		cout << valor->operator string() << " ";
	}

}

