#include "arff_parser.h"
#include <vector>
#include <iostream>
#include <string>
#include <numeric>
#include <functional>
#include <math.h>

using namespace std;


template<class Iter_T, class Iter2_T>
double vectorDistance(Iter_T first, Iter_T last, Iter2_T first2) {
  double ret = 0.0;
  while (first != last) {
    double dist = (*first++) - (*first2++);
    ret += dist * dist;
  }
  return ret > 0.0 ? sqrt(ret) : 0.0;
}



void lectorARFF(int idArchivo,	std::vector<vector <double> > &v,int &numeroFilas,int &numeroAtributos){
	ArffParser parser("ejemplo2.arff");
	ArffData *data = parser.parse();
	
	numeroFilas=data->num_instances();
	numeroAtributos=data->num_attributes();

	//cout << data->num_attributes() << endl;
	//cout << data->num_instances() << endl;
	
	ArffValue *valor;
	ArffInstance *instancia;

	for(int j=0;j<numeroFilas;j++){
		instancia = data->get_instance(j);
		std::vector<double> aux;

		for (int i = 0; i < data->num_attributes(); i++) {
			aux.push_back(stod(instancia->get(i)->operator string()) );
		}
		v.push_back(aux);
		aux.clear();
	}

}

void calculaMinMax(vector<vector <double> > &v,vector<double> &minimoColumnas,vector<double>  &maximoColumnas,int numeroFilas,int numeroAtributos){
	maximoColumnas=minimoColumnas=v[0];
	for(int i=0;i<numeroFilas;i++){
		for(int j=0;j<numeroAtributos;j++){
			if(v[i][j]>maximoColumnas[j])
				maximoColumnas[j]=v[i][j];
			if(v[i][j]<minimoColumnas[j])
				minimoColumnas[j]=v[i][j];
		}
	}

}


void normalizador(const vector<vector <double> > &v,vector<vector <double> > &vNormalizado,int numeroFilas,int numeroAtributos,vector<double> &minimoColumnas,vector<double>  &maximoColumnas){
	std::vector<double> aux;
	for(int i=0;i<numeroFilas;i++){
		for(int j=0;j<numeroAtributos-1;j++){
			if(isnan((v[i][j]-minimoColumnas[j])/(maximoColumnas[j]-minimoColumnas[j])))
				aux.push_back(0);
			else
			aux.push_back((v[i][j]-minimoColumnas[j])/(maximoColumnas[j]-minimoColumnas[j]));
		}
		vNormalizado.push_back(aux);
		aux.clear();
	}


}

void aplicaMascara(vector<vector <double> > &vNormalizado,vector<vector <double> > &vConMascara,vector<int> &mask,int numeroFilas,int numeroAtributos){
	std::vector<double> aux;

	for(int i=0;i<numeroFilas;i++){
		for(int j=0;j<numeroAtributos;j++){
			aux.push_back(vNormalizado[i][j]*mask[j]);
		}
		vConMascara.push_back(aux);
		aux.clear();
	}
}

double calculaEuclidea(vector<double> &aux,vector<double> &ejemploElegido){
	return vectorDistance(aux.begin(), aux.end(), ejemploElegido.begin());
}

void distanciaEuclidea(vector<double> &ejemploElegido,vector<vector <double> > &vConMascara,vector<double> &vectorDistancias,int numeroFilas,int numeroAtributos){
vector<double> aux;
	for(int i=0;i<numeroFilas;i++){
		aux=vConMascara[i];
		vectorDistancias.push_back(calculaEuclidea(aux,ejemploElegido));
	}
}


void calculaMenores(vector<double> &vectorDistancias,int &valor1, int &valor2, int &valor3){
	valor1=0;
	valor2=1;

for(int i=0;i<vectorDistancias.size();i++)
	if(vectorDistancias[i]<vectorDistancias[valor1] && i!=valor3 && i!=valor2)
		valor1=i;

for(int i=0;i<vectorDistancias.size();i++){
	if(vectorDistancias[i]<vectorDistancias[valor2] && i!=valor1 && i!=valor3){
		valor2=i;
	}
}
	valor3=0;

for(int i=0;i<vectorDistancias.size();i++){
	if(vectorDistancias[i]<vectorDistancias[valor3] && (i!=valor1 && i!=valor2)){
		valor3=i;
	}
}
}

int indiceMaximo(vector<int> &resultado){
	int indice=0;
	for(int i=0;i<resultado.size();i++)
			if(resultado[i]>resultado[indice])
				indice=i;
	return indice;
}


int knnClas(const vector<vector <double> > &v,vector<vector <double> > &vNormalizado,int ejemplo, vector<int> &mask,int numeroFilas,int numeroAtributos){
	vector<vector <double> > vConMascara;
	aplicaMascara(vNormalizado,vConMascara,mask,numeroFilas,numeroAtributos);

	vector<double> ejemploElegido=vConMascara[ejemplo];

	vector<double> vectorDistancias;
	distanciaEuclidea(ejemploElegido,vConMascara,vectorDistancias,numeroFilas,numeroAtributos);
	int valor1, valor2,  valor3;
	calculaMenores(vectorDistancias,valor1, valor2, valor3);

	if(v[valor1][numeroAtributos-1]==v[valor2][numeroAtributos-1])
		return v[valor1][numeroAtributos-1];
	if(v[valor2][numeroAtributos-1]==v[valor3][numeroAtributos-1])
		return v[valor2][numeroAtributos-1];
	if(v[valor3][numeroAtributos-1]==v[valor1][numeroAtributos-1])
		return v[valor3][numeroAtributos-1];
	return v[valor1][numeroAtributos-1];

}

void sfs(const vector<vector <double> > &v,vector<vector <double> > &vNormalizado, vector<int> &mask,int numeroFilas,int numeroAtributos,vector<int> &resultado){

bool seguir=true;
vector<int> mascaraAuxiliar=resultado;

		for(int i=0;i<numeroAtributos-1;i++){
			mask[i]=1;
			for(int j=0;j<numeroFilas;j++){
				if(knnClas(v,vNormalizado,j,mask,numeroFilas,numeroAtributos)==v[j][numeroAtributos-1])
					resultado[i]=resultado[i]+1;
			}
			mask[i]=0;
		}
		mascaraAuxiliar[indiceMaximo(resultado)]=1;
		mask[indiceMaximo(resultado)]=1;
		int aciertosAnt=resultado[indiceMaximo(resultado)];


	while(seguir){
		for(int i=0;i<numeroAtributos-1;i++){
				mask[i]=1;
			for(int j=0;j<numeroFilas;j++){
				if(knnClas(v,vNormalizado,j,mask,numeroFilas,numeroAtributos)==v[j][numeroAtributos-1])
					resultado[i]=resultado[i]+1;
			}
			if(resultado[i]>aciertosAnt){
				mascaraAuxiliar[i]=1;
				aciertosAnt=resultado[i];
			}
			else{
				seguir=false;
			}

			if(mascaraAuxiliar[i]!=1)
			mask[i]=0;
			}
		}
resultado=mascaraAuxiliar;

}



int main(){
	std::vector<vector <double> > vectorEntero;
	std::vector<vector <double> > v;
	std::vector<vector <double> > data;

	int numeroFilasI;
	int numeroAtributosI;
	lectorARFF(1,vectorEntero,numeroFilasI,numeroAtributosI);

	for(int i=0;i<numeroFilasI;i++){
		if(i<numeroFilasI/2)
		v.push_back(vectorEntero[i]);
		else
		data.push_back(vectorEntero[i]);
	}

	int numeroFilas= numeroFilasI-numeroFilasI/2;
	int numeroAtributos=numeroAtributosI;

	vector<double> minimoColumnas;
	vector<double> maximoColumnas;




clock_t startTime = clock();
	std::vector<vector <double> > vNormalizado;
	calculaMinMax(v,minimoColumnas,maximoColumnas,numeroFilas,numeroAtributos);


	normalizador(v,vNormalizado,numeroFilas,numeroAtributos,minimoColumnas,maximoColumnas);


//	for(int i=0;i<numeroAtributos-1;i++)
		//cout << vNormalizado[0][i]<<" ";
		
	vector<int> mask;
	vector<int> resultado;
	for(int i=0;i<numeroAtributos-1;i++){
		mask.push_back(0);
		resultado.push_back(0);
	}
	mask[1]=1;

	//cout << knnClas(v,vNormalizado,2,mask,numeroFilas,numeroAtributos)<< endl;



	sfs(v,vNormalizado,mask,numeroFilasI/2,numeroAtributos,resultado);
	for(int i=0;i<resultado.size();i++)
		cout << resultado[i] << " ";
	cout << double( clock() - startTime ) / (double)CLOCKS_PER_SEC<< " seconds." << endl;
	
/*
*/
	/*
	for(int i=0;i<numeroAtributos-1;i++)
		cout << mask[i]<<" ";
		

	for(int i=0;i<maximoColumnas.size();i++){
					cout << maximoColumnas[i]<<" ";
	}
	cout << endl;
	*/

	/*
	for(int i=0;i<numeroFilas;i++){
		for(int j=0;j<numeroAtributos;j++){
			cout << v[i][j] <<" ";
		}
		cout << endl;
	}
*/
}
